
let pages = document.querySelectorAll(".page");
let current = 0;

function showPage(index) {
    pages.forEach(p => p.classList.remove("active"));
    if (pages[index]) {
        pages[index].classList.add("active");
    }
}

function nextPage() {
    showPage(current);
    current++;
    if (current < pages.length) {
        setTimeout(nextPage, 4000);
    }
}

window.onload = () => {
    nextPage();
};
